﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-58UASJ8\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
