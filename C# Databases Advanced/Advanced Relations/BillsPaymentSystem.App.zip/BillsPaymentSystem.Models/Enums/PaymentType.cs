﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BillsPaymentSystem.Models.Enums
{
    public enum PaymentType
    {
        BankAccount = 0,
        CreditCard = 1
    }
}
