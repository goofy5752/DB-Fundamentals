﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BillsPaymentSystem.Data
{
    public class Config
    {
        public const string SqlConnect = @"Server=DESKTOP-58UASJ8\SQLEXPRESS;Database=BillsPaymentSystem;Integrated Security=True";
    }
}
