﻿namespace P03_FootballBetting.Data.Models
{
    public enum PredictionType
    {
        HomeTeam = 1,
        Draw = 'x',
        AwayTeam = 2
    }
}