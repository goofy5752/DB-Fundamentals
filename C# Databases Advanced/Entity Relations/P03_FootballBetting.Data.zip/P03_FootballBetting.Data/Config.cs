﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    public class Config
    {
        public const string SqlConnect = @"Server=DESKTOP-58UASJ8\SQLEXPRESS;Database=FootballBetting;Integrated Security = True";
    }
}
